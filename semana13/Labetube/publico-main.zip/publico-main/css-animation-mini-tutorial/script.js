ativar.addEventListener('click', () => {
  modal.classList.toggle('animar');
});
