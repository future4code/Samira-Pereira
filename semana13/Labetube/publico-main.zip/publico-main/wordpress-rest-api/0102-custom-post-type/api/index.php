<?php wp_head(); ?>
<p>API</p>
<?php wp_footer(); ?>